# Leobot 0.10.1 — sistema experimental

<p lang="es" style="text-align: justify; hyphens: auto;">Leobot reúne tres líneas de trabajo: lectura de frases y documentos, elección de estrategias aprendida de experiencias y uso en conversación de procedimientos y metas enseñados. Funciona en Python con procesador común; el motor usa solo la biblioteca incluida con Python. Es un proyecto de investigación: las pruebas actuales no demuestran conversación abierta, inteligencia general ni superioridad frente a los asistentes más avanzados.</p>

```bash
./run_tests.sh --solo-pruebas
./run_tests.sh
python3 -m leobot --help
python3 -m experiments.meta_feature_order_probe  # sonda opcional del orden
python3 -m experiments.user_text_probe           # lectura de frases del encargo
```

<p lang="es" style="text-align: justify; hyphens: auto;">La primera orden ejecuta las pruebas automáticas. La segunda también vuelve a ejecutar los experimentos y actualiza sus resultados en <code>results_v3/</code>. La sonda del orden comprueba que mover los datos útiles no impida aprender la misma regla. Sigue existiendo otro límite: dos señales que siempre coinciden en los ejemplos pueden confundirse al cambiar las condiciones.</p>

<p lang="es" style="text-align: justify; hyphens: auto;">El estado, las cifras, las decisiones de fusión, los fallos y la siguiente prueba están en <a href="LEOBOT_STATE.md">LEOBOT_STATE.md</a>. La versión unificada se entrega como un solo ZIP estable; los archivos antiguos se retiraron después de verificarla.</p>

## Dónde está cada parte

| Carpeta | Contenido |
|---|---|
| <code>leobot/</code> | Motor que aprende, guarda y responde |
| <code>experiments/</code> | Experimentos reproducibles; ejecutar con <code>python3 -m experiments.nombre</code> desde la raíz |
| <code>tests/</code> | Pruebas automáticas |
| <code>results_v3/</code> | Resultados conservados de los experimentos |
| <code>examples/</code> y <code>knowledge/</code> | Datos de ejemplo y materiales iniciales |

## Dónde cambiar cada capacidad

| Archivo | Responsabilidad |
|---|---|
| <code>leobot/bot.py</code> | Estado compartido, conexión entre aprendices y guardado en archivo |
| <code>leobot/document.py</code> | Lectura de documentos y elección de referentes |
| <code>leobot/language_acquisition.py</code> | Aprendizaje de formas de frases y relaciones sin significado previo |
| <code>leobot/conditional_learning.py</code> | Preguntas transformadas y reglas condicionales |
| <code>leobot/dialogue.py</code> | Conversación, correcciones y construcción de respuestas |
| <code>leobot/procedures.py</code> y <code>leobot/symbolic.py</code> | Acciones numéricas y planificación con estados explícitos |
| <code>leobot/metacontrol.py</code> | Elección de estrategias y búsqueda de reglas sobre experiencias anteriores |
| <code>leobot/scalable.py</code> | Guardado con los hechos en disco |
| <code>leobot/state_fields.py</code> | Campos aprendidos que ambas formas de guardado conservan |

<p lang="es" style="text-align: justify; hyphens: auto;">Para ampliar una capacidad, modifica su módulo, añade una prueba que falle antes del cambio y compara el experimento con la versión anterior y con un control sin el mecanismo. Si agregas información que debe sobrevivir al reinicio, verifica las dos formas de guardado. Registra la medición y el límite en <a href="LEOBOT_STATE.md">LEOBOT_STATE.md</a>; no conviertas el resultado de una prueba preparada en una afirmación de inteligencia general.</p>

## En palabras fáciles de entender

<p lang="es" style="text-align: justify; hyphens: auto;">Leobot intenta aprender reglas que una persona pueda revisar. Se unieron tres versiones hechas por separado y se conservaron las funciones que resistieron las pruebas. El motor, los experimentos, las pruebas y los resultados están ahora en carpetas distintas para que sea fácil encontrar cada cosa. Puede resolver algunas tareas que se le enseñan con ejemplos, pero todavía falla con muchas frases normales: en una pequeña prueba con texto escrito por el usuario no pudo contestar ninguna de cuatro preguntas. Las cifras altas que aparecen en ciertos experimentos corresponden a problemas preparados y repetitivos; no significan que pueda conversar o trabajar como los asistentes actuales.</p>
